import { useState, useMemo } from "react";
import { unitCategories, categoryOrder, convertUnit } from "../utils/converter.js";
import { formatNumber } from "../utils/math.js";

export default function Converter({ colors, lang, t }) {
  const [category, setCategory] = useState("length");
  const catUnits = unitCategories[category].units;
  const [fromUnit, setFromUnit] = useState(catUnits[0].key);
  const [toUnit, setToUnit] = useState(catUnits[1].key);
  const [amount, setAmount] = useState("1");

  const changeCategory = (cat) => {
    setCategory(cat);
    const units = unitCategories[cat].units;
    setFromUnit(units[0].key);
    setToUnit(units[1].key);
  };

  const swap = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
  };

  const result = useMemo(() => {
    const amt = parseFloat(amount);
    if (isNaN(amt)) return "";
    const value = convertUnit(amt, fromUnit, toUnit, catUnits);
    return value === null ? "" : formatNumber(value);
  }, [amount, fromUnit, toUnit, catUnits]);

  const selectStyle = { backgroundColor: colors.surface, color: colors.text, borderColor: colors.border };

  return (
    <div className="page-column">
      <div className="chip-row">
        {categoryOrder.map((cat) => (
          <button
            key={cat}
            onClick={() => changeCategory(cat)}
            className="chip-btn"
            style={
              category === cat
                ? { backgroundColor: colors.accent, color: colors.primaryDeep }
                : { backgroundColor: colors.surfaceAlt, color: colors.textMuted }
            }
          >
            {t.categories[cat]}
          </button>
        ))}
      </div>

      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        placeholder={t.amount}
        className="app-input"
        style={selectStyle}
      />

      <div className="row-with-swap">
        <select value={fromUnit} onChange={(e) => setFromUnit(e.target.value)} className="app-select" style={selectStyle}>
          {catUnits.map((u) => (
            <option key={u.key} value={u.key}>{lang === "id" ? u.id : u.en}</option>
          ))}
        </select>
        <button onClick={swap} className="swap-btn" style={{ backgroundColor: colors.surfaceAlt, color: colors.text }}>⇄</button>
        <select value={toUnit} onChange={(e) => setToUnit(e.target.value)} className="app-select" style={selectStyle}>
          {catUnits.map((u) => (
            <option key={u.key} value={u.key}>{lang === "id" ? u.id : u.en}</option>
          ))}
        </select>
      </div>

      <div className="result-box" style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
        <div className="result-label" style={{ color: colors.textMuted }}>{t.result}</div>
        <div className="result-value">{result || "—"}</div>
      </div>
    </div>
  );
}
