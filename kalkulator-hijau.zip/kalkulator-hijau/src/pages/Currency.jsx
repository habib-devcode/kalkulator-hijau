import { useState, useMemo } from "react";
import { currencies, convertCurrency } from "../utils/currency.js";
import { formatNumber } from "../utils/math.js";

export default function Currency({ colors, lang, t }) {
  const [from, setFrom] = useState("USD");
  const [to, setTo] = useState("IDR");
  const [amount, setAmount] = useState("1");

  const swap = () => {
    setFrom(to);
    setTo(from);
  };

  const result = useMemo(() => {
    const amt = parseFloat(amount);
    if (isNaN(amt)) return "";
    const value = convertCurrency(amt, from, to);
    return value === null ? "" : formatNumber(value);
  }, [amount, from, to]);

  const selectStyle = { backgroundColor: colors.surface, color: colors.text, borderColor: colors.border };

  return (
    <div className="page-column">
      <input
        type="number"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
        placeholder={t.amount}
        className="app-input"
        style={selectStyle}
      />
      <div className="row-with-swap">
        <select value={from} onChange={(e) => setFrom(e.target.value)} className="app-select" style={selectStyle}>
          {currencies.map((c) => (
            <option key={c.key} value={c.key}>{lang === "id" ? c.id : c.en}</option>
          ))}
        </select>
        <button onClick={swap} className="swap-btn" style={{ backgroundColor: colors.surfaceAlt, color: colors.text }}>⇄</button>
        <select value={to} onChange={(e) => setTo(e.target.value)} className="app-select" style={selectStyle}>
          {currencies.map((c) => (
            <option key={c.key} value={c.key}>{lang === "id" ? c.id : c.en}</option>
          ))}
        </select>
      </div>
      <div className="result-box" style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
        <div className="result-label" style={{ color: colors.textMuted }}>{t.result}</div>
        <div className="result-value">{result || "—"}</div>
      </div>
      <p className="note-text" style={{ color: colors.textMuted }}>{t.rateNote}</p>
    </div>
  );
}
