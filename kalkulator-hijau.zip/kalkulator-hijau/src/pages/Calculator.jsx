import { useState } from "react";
import Button from "../components/Button.jsx";
import Display from "../components/Display.jsx";
import { evaluateExpression, applyFunction, formatNumber } from "../utils/math.js";

const OP_CHARS = ["+", "-", "×", "÷", "^"];

// Buang operator yang "nyantol" di akhir sebelum dihitung.
// Contoh: "9+" -> "9", "6÷" -> "6"
function stripTrailingOperator(str) {
  let result = str;
  while (result.length > 0 && OP_CHARS.includes(result[result.length - 1])) {
    result = result.slice(0, -1);
  }
  return result || "0";
}

export default function Calculator({ colors }) {
  const [expr, setExpr] = useState("0");
  const [justEvaluated, setJustEvaluated] = useState(false);

  const pressDigit = (d) => {
    if (expr === "Error" || justEvaluated) setExpr(d);
    else setExpr(expr === "0" ? d : expr + d);
    setJustEvaluated(false);
  };

  const pressDot = () => {
    const parts = expr.split(/[+\-×÷^()]/);
    const last = parts[parts.length - 1];
    if (last.includes(".")) return;
    if (expr === "Error" || justEvaluated) setExpr("0.");
    else setExpr(expr + ".");
    setJustEvaluated(false);
  };

  const pressOp = (op) => {
    if (expr === "Error") return;
    if (OP_CHARS.includes(expr[expr.length - 1])) setExpr(expr.slice(0, -1) + op);
    else setExpr(expr + op);
    setJustEvaluated(false);
  };

  const pressParen = (p) => {
    if (expr === "Error") { setExpr(p); return; }
    setExpr(justEvaluated ? p : expr + p);
    setJustEvaluated(false);
  };

  const pressPi = () => {
    setExpr(justEvaluated || expr === "0" || expr === "Error" ? "π" : expr + "π");
    setJustEvaluated(false);
  };

  const pressClear = () => { setExpr("0"); setJustEvaluated(false); };

  const pressBackspace = () => {
    if (expr === "Error" || expr.length <= 1) { setExpr("0"); return; }
    setExpr(expr.slice(0, -1));
  };

  const pressFn = (fn) => {
    try {
      const clean = stripTrailingOperator(expr);
      const val = evaluateExpression(clean);
      const res = applyFunction(fn, val);
      setExpr(formatNumber(res));
      setJustEvaluated(true);
    } catch {
      setExpr("Error");
      setJustEvaluated(true);
    }
  };

  const pressEquals = () => {
    try {
      const clean = stripTrailingOperator(expr);
      setExpr(formatNumber(evaluateExpression(clean)));
    } catch {
      setExpr("Error");
    }
    setJustEvaluated(true);
  };

  return (
    <div className="page-column">
      <Display value={expr} colors={colors} />

      <div className="grid-5">
        <Button label="sin" onClick={() => pressFn("sin")} variant="fn" colors={colors} />
        <Button label="cos" onClick={() => pressFn("cos")} variant="fn" colors={colors} />
        <Button label="tan" onClick={() => pressFn("tan")} variant="fn" colors={colors} />
        <Button label="log" onClick={() => pressFn("log")} variant="fn" colors={colors} />
        <Button label="√" onClick={() => pressFn("sqrt")} variant="fn" colors={colors} />
        <Button label="x²" onClick={() => pressFn("square")} variant="fn" colors={colors} />
        <Button label="x³" onClick={() => pressFn("cube")} variant="fn" colors={colors} />
        <Button label="^" onClick={() => pressOp("^")} variant="fn" colors={colors} />
        <Button label="π" onClick={pressPi} variant="fn" colors={colors} />
        <Button label="%" onClick={() => pressFn("percent")} variant="fn" colors={colors} />
      </div>

      <div className="grid-4">
        <Button label="C" onClick={pressClear} variant="clear" colors={colors} />
        <Button label="⌫" onClick={pressBackspace} colors={colors} />
        <Button label="(" onClick={() => pressParen("(")} colors={colors} />
        <Button label=")" onClick={() => pressParen(")")} colors={colors} />

        <Button label="7" onClick={() => pressDigit("7")} colors={colors} />
        <Button label="8" onClick={() => pressDigit("8")} colors={colors} />
        <Button label="9" onClick={() => pressDigit("9")} colors={colors} />
        <Button label="÷" onClick={() => pressOp("÷")} variant="op" colors={colors} />

        <Button label="4" onClick={() => pressDigit("4")} colors={colors} />
        <Button label="5" onClick={() => pressDigit("5")} colors={colors} />
        <Button label="6" onClick={() => pressDigit("6")} colors={colors} />
        <Button label="×" onClick={() => pressOp("×")} variant="op" colors={colors} />

        <Button label="1" onClick={() => pressDigit("1")} colors={colors} />
        <Button label="2" onClick={() => pressDigit("2")} colors={colors} />
        <Button label="3" onClick={() => pressDigit("3")} colors={colors} />
        <Button label="-" onClick={() => pressOp("-")} variant="op" colors={colors} />

        <Button label="0" onClick={() => pressDigit("0")} colors={colors} />
        <Button label="." onClick={pressDot} colors={colors} />
        <Button label="=" onClick={pressEquals} variant="equals" colors={colors} />
        <Button label="+" onClick={() => pressOp("+")} variant="op" colors={colors} />
      </div>
    </div>
  );
}
