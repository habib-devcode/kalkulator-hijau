import { useState, useMemo } from "react";

export default function BMI({ colors, t }) {
  const [weight, setWeight] = useState("");
  const [height, setHeight] = useState("");

  const bmi = useMemo(() => {
    const w = parseFloat(weight);
    const h = parseFloat(height);
    if (!w || !h) return null;
    const hm = h / 100;
    return w / (hm * hm);
  }, [weight, height]);

  const category = useMemo(() => {
    if (bmi === null) return null;
    if (bmi < 18.5) return { label: t.bmiCats.under, color: colors.accent };
    if (bmi < 25) return { label: t.bmiCats.normal, color: colors.primary };
    if (bmi < 30) return { label: t.bmiCats.over, color: colors.accentDeep };
    return { label: t.bmiCats.obese, color: colors.danger };
  }, [bmi, t, colors]);

  const selectStyle = { backgroundColor: colors.surface, color: colors.text, borderColor: colors.border };

  return (
    <div className="page-column">
      <input
        type="number"
        value={weight}
        onChange={(e) => setWeight(e.target.value)}
        placeholder={t.weight}
        className="app-input"
        style={selectStyle}
      />
      <input
        type="number"
        value={height}
        onChange={(e) => setHeight(e.target.value)}
        placeholder={t.height}
        className="app-input"
        style={selectStyle}
      />
      <div className="result-box" style={{ backgroundColor: colors.surface, borderColor: colors.border }}>
        <div className="result-label" style={{ color: colors.textMuted }}>{t.bmiResult}</div>
        {bmi === null ? (
          <div className="note-text" style={{ color: colors.textMuted }}>{t.enterValues}</div>
        ) : (
          <>
            <div className="result-value">{bmi.toFixed(1)}</div>
            <span className="badge" style={{ backgroundColor: category.color }}>{category.label}</span>
          </>
        )}
      </div>
    </div>
  );
}
