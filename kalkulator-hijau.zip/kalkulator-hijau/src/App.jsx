import { useState } from "react";
import Tabs from "./components/Tabs.jsx";
import Calculator from "./pages/Calculator.jsx";
import Converter from "./pages/Converter.jsx";
import Currency from "./pages/Currency.jsx";
import BMI from "./pages/BMI.jsx";
import { lightTokens, darkTokens } from "./constants/colors.js";
import { dict } from "./constants/language.js";
import "./App.css";

export default function App() {
  const [theme, setTheme] = useState("light");
  const [lang, setLang] = useState("id");
  const [tab, setTab] = useState("calc");

  const isDark = theme === "dark";
  const colors = isDark ? darkTokens : lightTokens;
  const t = dict[lang];

  const tabs = [
    { key: "calc", label: t.tabs.calc, icon: "🧮" },
    { key: "convert", label: t.tabs.convert, icon: "📏" },
    { key: "currency", label: t.tabs.currency, icon: "💱" },
    { key: "bmi", label: t.tabs.bmi, icon: "⚖️" },
  ];

  return (
    <div className="app-root" style={{ backgroundColor: colors.bg, color: colors.text }}>
      <div className="app-container">
        <div className="app-header">
          <div className="app-title">
            <div className="app-logo" style={{ backgroundColor: colors.primary }}>🧮</div>
            <span>{t.appTitle}</span>
          </div>
          <div className="app-header-actions">
            <button
              onClick={() => setLang(lang === "id" ? "en" : "id")}
              className="lang-btn"
              style={{ backgroundColor: colors.surfaceAlt, color: colors.text }}
            >
              {lang.toUpperCase()}
            </button>
            <button
              onClick={() => setTheme(isDark ? "light" : "dark")}
              className="theme-btn"
              style={{ backgroundColor: colors.surfaceAlt, color: colors.text }}
            >
              {isDark ? "☀️" : "🌙"}
            </button>
          </div>
        </div>

        <Tabs tabs={tabs} activeTab={tab} onChange={setTab} colors={colors} />

        {tab === "calc" && <Calculator colors={colors} />}
        {tab === "convert" && <Converter colors={colors} lang={lang} t={t} />}
        {tab === "currency" && <Currency colors={colors} lang={lang} t={t} />}
        {tab === "bmi" && <BMI colors={colors} t={t} />}
      </div>
    </div>
  );
}
