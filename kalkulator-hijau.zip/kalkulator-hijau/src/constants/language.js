// Kamus terjemahan Indonesia <-> Inggris.
// Struktur key HARUS sama persis di kedua bahasa, atau teks akan "undefined".

export const dict = {
  id: {
    appTitle: "Kalkulator Hijau",
    tabs: { calc: "Kalkulator", convert: "Konversi", currency: "Kurs", bmi: "BMI" },
    amount: "Jumlah",
    result: "Hasil",
    weight: "Berat badan (kg)",
    height: "Tinggi badan (cm)",
    bmiResult: "Indeks Massa Tubuh (BMI)",
    rateNote: "Kurs contoh untuk latihan, bukan data pasar real-time.",
    categories: { length: "Panjang", mass: "Massa", area: "Luas", volume: "Volume", time: "Waktu", data: "Data" },
    bmiCats: { under: "Kurang berat badan", normal: "Berat badan normal", over: "Kelebihan berat badan", obese: "Obesitas" },
    enterValues: "Masukkan berat dan tinggi badan",
  },
  en: {
    appTitle: "Green Calculator",
    tabs: { calc: "Calculator", convert: "Convert", currency: "Currency", bmi: "BMI" },
    amount: "Amount",
    result: "Result",
    weight: "Weight (kg)",
    height: "Height (cm)",
    bmiResult: "Body Mass Index (BMI)",
    rateNote: "Example rates for practice, not live market data.",
    categories: { length: "Length", mass: "Mass", area: "Area", volume: "Volume", time: "Time", data: "Data" },
    bmiCats: { under: "Underweight", normal: "Normal weight", over: "Overweight", obese: "Obese" },
    enterValues: "Enter your weight and height",
  },
};
