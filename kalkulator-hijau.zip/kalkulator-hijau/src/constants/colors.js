// Token warna untuk tema terang dan gelap.
// Disimpan sebagai object supaya gampang di-ganti tanpa menyentuh komponen UI.

export const lightTokens = {
  bg: "#F6FAF4",
  surface: "#FFFFFF",
  surfaceAlt: "#EDF5E8",
  primary: "#2F9E58",
  primaryDeep: "#1E6B3C",
  accent: "#F2C14E",
  accentDeep: "#C98F12",
  text: "#16241A",
  textMuted: "#5C6B5E",
  border: "#DCEAD4",
  danger: "#D64545",
};

export const darkTokens = {
  bg: "#0E1712",
  surface: "#16211A",
  surfaceAlt: "#1D2B21",
  primary: "#4ADE80",
  primaryDeep: "#34B368",
  accent: "#FBBF24",
  accentDeep: "#D9930F",
  text: "#EAF6EC",
  textMuted: "#8FA895",
  border: "#274031",
  danger: "#F87171",
};
