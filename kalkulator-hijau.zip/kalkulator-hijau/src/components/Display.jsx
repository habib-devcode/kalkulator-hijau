// Kotak layar yang menampilkan ekspresi/angka. Dipakai di halaman Calculator.

export default function Display({ value, colors }) {
  return (
    <div
      className="app-display"
      style={{ backgroundColor: colors.surface, borderColor: colors.border, color: colors.text }}
    >
      {value}
    </div>
  );
}
