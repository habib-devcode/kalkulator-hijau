// Tombol generik yang dipakai ulang di seluruh app (angka, operator, fungsi, dll).
// "variant" menentukan warnanya, "colors" adalah token tema yang sedang aktif.

export default function Button({ label, onClick, variant = "num", colors, className = "" }) {
  const styles = {
    num: { backgroundColor: colors.surfaceAlt, color: colors.text },
    op: { backgroundColor: colors.primary, color: "#FFFFFF" },
    fn: { backgroundColor: colors.accent, color: colors.primaryDeep },
    clear: { backgroundColor: colors.danger, color: "#FFFFFF" },
    equals: { backgroundColor: colors.primaryDeep, color: "#FFFFFF" },
  };

  return (
    <button onClick={onClick} className={"app-btn " + className} style={styles[variant]}>
      {label}
    </button>
  );
}
