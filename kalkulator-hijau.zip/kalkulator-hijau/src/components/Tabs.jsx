// Baris tab navigasi (Kalkulator / Konversi / Kurs / BMI).

export default function Tabs({ tabs, activeTab, onChange, colors }) {
  return (
    <div className="app-tabs">
      {tabs.map(({ key, label, icon }) => (
        <button
          key={key}
          onClick={() => onChange(key)}
          className="app-tab-btn"
          style={
            activeTab === key
              ? { backgroundColor: colors.primary, color: "#FFFFFF" }
              : { backgroundColor: colors.surfaceAlt, color: colors.textMuted }
          }
        >
          <span>{icon}</span>
          <span>{label}</span>
        </button>
      ))}
    </div>
  );
}
