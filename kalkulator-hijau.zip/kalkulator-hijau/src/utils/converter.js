// Data & logika konversi satuan.
// "factor" = berapa satuan dasar (meter/kg/liter/dst) yang setara 1 unit ini.

export const unitCategories = {
  length: {
    units: [
      { key: "mm", factor: 0.001, id: "Milimeter (mm)", en: "Millimeter (mm)" },
      { key: "cm", factor: 0.01, id: "Sentimeter (cm)", en: "Centimeter (cm)" },
      { key: "m", factor: 1, id: "Meter (m)", en: "Meter (m)" },
      { key: "km", factor: 1000, id: "Kilometer (km)", en: "Kilometer (km)" },
      { key: "in", factor: 0.0254, id: "Inci (in)", en: "Inch (in)" },
      { key: "ft", factor: 0.3048, id: "Kaki (ft)", en: "Foot (ft)" },
      { key: "yd", factor: 0.9144, id: "Yard (yd)", en: "Yard (yd)" },
      { key: "mi", factor: 1609.344, id: "Mil (mi)", en: "Mile (mi)" },
    ],
  },
  mass: {
    units: [
      { key: "mg", factor: 0.000001, id: "Miligram (mg)", en: "Milligram (mg)" },
      { key: "g", factor: 0.001, id: "Gram (g)", en: "Gram (g)" },
      { key: "kg", factor: 1, id: "Kilogram (kg)", en: "Kilogram (kg)" },
      { key: "ton", factor: 1000, id: "Ton", en: "Metric ton" },
      { key: "oz", factor: 0.0283495, id: "Ons (oz)", en: "Ounce (oz)" },
      { key: "lb", factor: 0.453592, id: "Pon (lb)", en: "Pound (lb)" },
    ],
  },
  area: {
    units: [
      { key: "m2", factor: 1, id: "Meter persegi (m²)", en: "Square meter (m²)" },
      { key: "km2", factor: 1e6, id: "Kilometer persegi (km²)", en: "Square kilometer (km²)" },
      { key: "ha", factor: 10000, id: "Hektar (ha)", en: "Hectare (ha)" },
      { key: "acre", factor: 4046.8564224, id: "Acre", en: "Acre" },
      { key: "ft2", factor: 0.09290304, id: "Kaki persegi (ft²)", en: "Square foot (ft²)" },
    ],
  },
  volume: {
    units: [
      { key: "ml", factor: 0.001, id: "Mililiter (ml)", en: "Milliliter (ml)" },
      { key: "l", factor: 1, id: "Liter (l)", en: "Liter (l)" },
      { key: "m3", factor: 1000, id: "Meter kubik (m³)", en: "Cubic meter (m³)" },
      { key: "gal", factor: 3.785411784, id: "Galon AS (gal)", en: "US Gallon (gal)" },
      { key: "cup", factor: 0.24, id: "Cangkir (cup)", en: "Cup" },
      { key: "tbsp", factor: 0.0147868, id: "Sendok makan (tbsp)", en: "Tablespoon (tbsp)" },
    ],
  },
  time: {
    units: [
      { key: "s", factor: 1, id: "Detik", en: "Second" },
      { key: "min", factor: 60, id: "Menit", en: "Minute" },
      { key: "h", factor: 3600, id: "Jam", en: "Hour" },
      { key: "d", factor: 86400, id: "Hari", en: "Day" },
      { key: "wk", factor: 604800, id: "Minggu", en: "Week" },
    ],
  },
  data: {
    units: [
      { key: "bit", factor: 0.125, id: "Bit", en: "Bit" },
      { key: "byte", factor: 1, id: "Byte", en: "Byte" },
      { key: "kb", factor: 1024, id: "Kilobyte (KB)", en: "Kilobyte (KB)" },
      { key: "mb", factor: 1024 ** 2, id: "Megabyte (MB)", en: "Megabyte (MB)" },
      { key: "gb", factor: 1024 ** 3, id: "Gigabyte (GB)", en: "Gigabyte (GB)" },
      { key: "tb", factor: 1024 ** 4, id: "Terabyte (TB)", en: "Terabyte (TB)" },
    ],
  },
};

export const categoryOrder = ["length", "mass", "area", "volume", "time", "data"];

export function convertUnit(amount, fromKey, toKey, units) {
  const from = units.find((u) => u.key === fromKey);
  const to = units.find((u) => u.key === toKey);
  if (!from || !to) return null;
  const base = amount * from.factor;
  return base / to.factor;
}
