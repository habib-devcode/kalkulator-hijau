// Data & logika konversi mata uang.
// "rate" = berapa unit mata uang ini setara 1 USD (USD dijadikan patokan/basis).
// CATATAN: angka ini statis untuk latihan, bukan data pasar real-time.

export const currencies = [
  { key: "USD", rate: 1, id: "Dolar AS (USD)", en: "US Dollar (USD)" },
  { key: "IDR", rate: 15800, id: "Rupiah (IDR)", en: "Indonesian Rupiah (IDR)" },
  { key: "EUR", rate: 0.93, id: "Euro (EUR)", en: "Euro (EUR)" },
  { key: "GBP", rate: 0.79, id: "Poundsterling (GBP)", en: "British Pound (GBP)" },
  { key: "JPY", rate: 151, id: "Yen Jepang (JPY)", en: "Japanese Yen (JPY)" },
  { key: "SGD", rate: 1.35, id: "Dolar Singapura (SGD)", en: "Singapore Dollar (SGD)" },
  { key: "AUD", rate: 1.52, id: "Dolar Australia (AUD)", en: "Australian Dollar (AUD)" },
  { key: "CNY", rate: 7.2, id: "Yuan Tiongkok (CNY)", en: "Chinese Yuan (CNY)" },
  { key: "KRW", rate: 1370, id: "Won Korea (KRW)", en: "Korean Won (KRW)" },
  { key: "MYR", rate: 4.7, id: "Ringgit Malaysia (MYR)", en: "Malaysian Ringgit (MYR)" },
];

export function convertCurrency(amount, fromKey, toKey) {
  const from = currencies.find((c) => c.key === fromKey);
  const to = currencies.find((c) => c.key === toKey);
  if (!from || !to) return null;
  const usd = amount / from.rate;
  return usd * to.rate;
}
