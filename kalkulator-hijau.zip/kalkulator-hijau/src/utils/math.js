// ============================================================
// Parser & evaluator ekspresi matematika BUATAN SENDIRI.
// TIDAK memakai eval() atau Function() sama sekali.
//
// Alurnya 3 tahap:
// 1. tokenize()   -> pecah teks jadi "kata-kata" (token): angka & operator
// 2. toPostfix()  -> susun ulang urutan token pakai algoritma Shunting-yard,
//                    supaya urutan operasi (misal * sebelum +) benar
// 3. evalPostfix()-> hitung hasil akhir dari urutan postfix itu
// ============================================================

const OPERATORS = {
  "+": { precedence: 1, associativity: "L" },
  "-": { precedence: 1, associativity: "L" },
  "*": { precedence: 2, associativity: "L" },
  "/": { precedence: 2, associativity: "L" },
  "^": { precedence: 3, associativity: "R" },
};

function tokenize(input) {
  const tokens = [];
  let i = 0;

  while (i < input.length) {
    const char = input[i];

    if (char === " ") {
      i++;
      continue;
    }

    const prev = tokens[tokens.length - 1];
    const isUnaryPosition =
      !prev || prev.type === "operator" || (prev.type === "paren" && prev.value === "(");

    // Minus di posisi "awal angka" dianggap tanda negatif, bukan operator kurang
    if (char === "-" && isUnaryPosition) {
      let j = i + 1;
      let num = "-";
      while (j < input.length && /[0-9.]/.test(input[j])) {
        num += input[j];
        j++;
      }
      if (num === "-") throw new Error("Angka setelah tanda minus tidak ditemukan");
      tokens.push({ type: "number", value: parseFloat(num) });
      i = j;
      continue;
    }

    if (/[0-9.]/.test(char)) {
      let j = i;
      let num = "";
      while (j < input.length && /[0-9.]/.test(input[j])) {
        num += input[j];
        j++;
      }
      tokens.push({ type: "number", value: parseFloat(num) });
      i = j;
      continue;
    }

    if ("+-*/^".includes(char)) {
      tokens.push({ type: "operator", value: char });
      i++;
      continue;
    }

    if (char === "(" || char === ")") {
      tokens.push({ type: "paren", value: char });
      i++;
      continue;
    }

    throw new Error(`Karakter tidak dikenali: "${char}"`);
  }

  return tokens;
}

function toPostfix(tokens) {
  const output = [];
  const opStack = [];

  for (const token of tokens) {
    if (token.type === "number") {
      output.push(token);
    } else if (token.type === "operator") {
      while (
        opStack.length > 0 &&
        opStack[opStack.length - 1].type === "operator" &&
        (OPERATORS[opStack[opStack.length - 1].value].precedence > OPERATORS[token.value].precedence ||
          (OPERATORS[opStack[opStack.length - 1].value].precedence === OPERATORS[token.value].precedence &&
            OPERATORS[token.value].associativity === "L"))
      ) {
        output.push(opStack.pop());
      }
      opStack.push(token);
    } else if (token.value === "(") {
      opStack.push(token);
    } else if (token.value === ")") {
      while (opStack.length > 0 && opStack[opStack.length - 1].value !== "(") {
        output.push(opStack.pop());
      }
      if (opStack.length === 0) throw new Error("Tanda kurung tidak seimbang");
      opStack.pop();
    }
  }

  while (opStack.length > 0) {
    const op = opStack.pop();
    if (op.value === "(" || op.value === ")") throw new Error("Tanda kurung tidak seimbang");
    output.push(op);
  }

  return output;
}

function evalPostfix(postfix) {
  const stack = [];

  for (const token of postfix) {
    if (token.type === "number") {
      stack.push(token.value);
      continue;
    }
    const b = stack.pop();
    const a = stack.pop();
    if (a === undefined || b === undefined) throw new Error("Ekspresi tidak valid");

    switch (token.value) {
      case "+": stack.push(a + b); break;
      case "-": stack.push(a - b); break;
      case "*": stack.push(a * b); break;
      case "/":
        if (b === 0) throw new Error("Tidak bisa membagi dengan nol");
        stack.push(a / b);
        break;
      case "^": stack.push(Math.pow(a, b)); break;
      default: throw new Error("Operator tidak dikenali: " + token.value);
    }
  }

  if (stack.length !== 1) throw new Error("Ekspresi tidak valid");
  return stack[0];
}

export function evaluateExpression(rawInput) {
  const input = rawInput
    .replaceAll("×", "*")
    .replaceAll("÷", "/")
    .replaceAll("π", String(Math.PI));

  const tokens = tokenize(input);
  const postfix = toPostfix(tokens);
  const result = evalPostfix(postfix);

  if (!isFinite(result)) throw new Error("Hasil tidak valid");
  return result;
}

export function toRadians(degrees) {
  return (degrees * Math.PI) / 180;
}

export function applyFunction(name, value) {
  switch (name) {
    case "sin": return Math.sin(toRadians(value));
    case "cos": return Math.cos(toRadians(value));
    case "tan": return Math.tan(toRadians(value));
    case "log": return Math.log10(value);
    case "sqrt": return Math.sqrt(value);
    case "square": return value ** 2;
    case "cube": return value ** 3;
    case "percent": return value / 100;
    default: throw new Error("Fungsi tidak dikenali: " + name);
  }
}

export function formatNumber(n) {
  if (!isFinite(n)) return "Error";
  const rounded = Math.round(n * 1e10) / 1e10;
  return String(rounded);
}
