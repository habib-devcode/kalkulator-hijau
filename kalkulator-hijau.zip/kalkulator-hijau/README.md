# Kalkulator Hijau

Kalkulator serba-guna: kalkulator saintifik, konversi satuan, kurs mata uang, dan BMI.
Dibangun dengan React + Vite. Semua perhitungan matematika pakai parser buatan sendiri
(lihat src/utils/math.js) — tidak memakai eval() atau Function().

## Menjalankan secara lokal

1. Install dependencies:
   npm install

2. Jalankan mode development:
   npm run dev

3. Buka alamat yang muncul di terminal (biasanya http://localhost:5173)

## Struktur folder

- src/components -> komponen UI yang dipakai berulang (Button, Display, Tabs)
- src/pages      -> satu halaman/tab per file (Calculator, Converter, Currency, BMI)
- src/utils      -> logika murni tanpa UI:
                     math.js (parser matematika), converter.js, currency.js
- src/constants  -> data statis: colors.js (tema), language.js (dwi-bahasa)
